# Swadharma Server

Core booking backend for the Swadharma professional-services platform —
search/filter, direct booking, live location tracking, payment, ratings,
and tiered cancellation. Express + TypeScript + PostgreSQL (Drizzle ORM),
same proven stack and patterns as `parichara-server`.

## Scope (deliberate)

This is the **core booking build only**, per an explicit scope decision.
**Not** included here, to be layered in later without needing to redesign
this core:

- 3-tier provider credentialing (SVAMI Certified / Credential Verified /
  Community Verified) — professionals here just have a self-declared
  profile, no admin approval gate
- Hub-and-spoke multi-tenancy with row-level security
- Pañcāṅga-aware muhūrta scheduling
- The fixed donation-tier pricing model ($30–$250) — this build uses a
  generic token-amount + capture flow instead, same shape as Parichara's

## Repo relationship

Separate service from `parichara-server` — not a shared database. Several
files (`errors.ts`, `services/smsProvider.ts`, `services/payment.ts`,
`services/push.ts`, `middleware/auth.ts`, `middleware/admin.ts`,
`scripts/make-admin.ts`, `services/otp.ts`) were copied over from
`parichara-server` as-is or with minimal adaptation (message text) — they're
generic, already-tested infrastructure, not Swadharma-specific code. If a
third project needs the same pieces, that's the signal to extract a shared
package; not before.

## Setup

```bash
cp .env.example .env   # fill in DATABASE_URL and JWT_SECRET
npm install
npm run generate       # drizzle-kit generates SQL under ./drizzle
# apply the generated .sql file(s) to your Postgres database
npm run dev             # starts on :4100 (or $PORT)
```

Bootstrap the first admin the same way as Parichara — no API endpoint
grants admin, only `npm run make-admin -- "<phone>"` (the phone must
already have signed in once).

## Structure

```
src/
  db/
    schema.ts       users, professional_profiles, bookings, ratings,
                    location_pings, wallet_transactions, notifications,
                    otp_challenges, push_tokens
    client.ts        Drizzle + pg pool
  middleware/
    auth.ts          JWT verification
    admin.ts          requireAdmin — checks users.isAdmin (separate from
                      the self-service roles array, same reasoning as
                      Parichara)
  routes/
    auth.ts            Phone OTP, role selection
    professionals.ts    Profile create/update + the search/filter endpoint
                        (Veda/Śākhā/Sūtra/specialty/language/rating)
    bookings.ts          Create/list/accept/status/payment/cancel
    ratings.ts            Post-completion ratings
    notifications.ts      In-app + best-effort push (notifyUser helper)
    locationPings.ts        Live tracking during an active booking window
    wallet.ts               Balance and transaction history
  services/
    otp.ts               OTP + DB-backed rate limiting
    smsProvider.ts         Pluggable SMS (console/msg91/twilio)
    push.ts                Pluggable push (none/fcm)
    payment.ts             Pluggable payment gateway (mock/razorpay)
    cancellationPolicy.ts  Tiered refund/credit/forfeiture — same logic
                          as Parichara's, reproduced not imported (see
                          the file's own comment on why)
  errors.ts             HttpError, respected by app.ts's error handler
scripts/
  make-admin.ts               Bootstrap the first admin
  cleanup-location-pings.ts   Retention job — run on a schedule
```

## Verified (actually run against a real Postgres instance)

- Requester and professional signup via phone OTP
- Professional profile creation (Veda/Śākhā/Sūtra/specialty/service area)
- **Search/filter**: confirmed a query matching Veda + specialty correctly
  finds the professional, and a query for a non-matching specialty
  correctly returns empty
- **Full booking lifecycle**: create → payment create-order → confirm →
  professional accepts (requester notified, both in-app and via a
  best-effort push to a registered device token) → live location ping and
  retrieval during an active window → status progression through to
  completed → rating submitted → **search now reflects the real computed
  average rating** (confirmed 5.0 after a single 5-star rating)
- **Cancellation policy, all four tiers**: before acceptance (full
  refund), after acceptance but before start (50/50 split — confirmed
  ₹50/₹50 on a ₹100 token), after work started (full forfeiture to the
  professional), and professional-initiated (full refund to requester,
  confirmed against final wallet balances for both parties)
- **Admin bootstrap**: `make-admin.ts` correctly grants `isAdmin` to an
  existing user by phone
- **Location-ping retention**: a backdated (48h) ping was correctly
  deleted by the cleanup script while using the default 24h retention
  window

## Not built yet

- The three deferred items from the scope note above (credentialing
  tiers, multi-tenancy/RLS, muhūrta scheduling, donation-tier pricing)
- Real SMS/push/payment provider verification — same caveat as
  `parichara-server`: `msg91`/`twilio`/`fcm`/`razorpay` adapters are
  copied over and written to real API shapes, but this sandbox's network
  allowlist doesn't reach any of those domains, so only the
  console/none/mock defaults have actually been exercised here
- Any client (mobile or web) — this is backend only, matching how
  Parichara was built (server proven first, client next)
- Booking broadcast to multiple matching professionals — this core build
  is direct booking of one professional found via search, not a
  broadcast/accept-race model (that's closer to Contract Works' shape)
- Any of the chatbot integration designed in `CHATBOT_SPEC.md` /
  `COMMON_CHATBOT_PLATFORM_SPEC.md` — those assumed this backend existing;
  it now does, so that's unblocked as a next step
