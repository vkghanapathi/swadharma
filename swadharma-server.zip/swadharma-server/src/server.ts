import 'dotenv/config';
import { createApp } from './app';

const port = process.env.PORT ? Number(process.env.PORT) : 4100;
const app = createApp();

app.listen(port, () => {
  // eslint-disable-next-line no-console
  console.log(`Swadharma server listening on :${port}`);
});
