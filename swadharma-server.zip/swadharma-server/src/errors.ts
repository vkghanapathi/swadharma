// A thrown error with an explicit HTTP status code. app.ts's error handler
// already respects err.statusCode when present (see the comment there about
// not collapsing every error to 500) — this is just a convenient class to
// throw one from inside a service, away from the request/response objects.
export class HttpError extends Error {
  statusCode: number;

  constructor(statusCode: number, message: string) {
    super(message);
    this.statusCode = statusCode;
  }
}
