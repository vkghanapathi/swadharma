import express from 'express';
import cors from 'cors';
import 'express-async-errors';

import authRoutes from './routes/auth';
import professionalsRoutes from './routes/professionals';
import bookingsRoutes from './routes/bookings';
import ratingsRoutes from './routes/ratings';
import notificationsRoutes from './routes/notifications';
import locationPingsRoutes from './routes/locationPings';
import walletRoutes from './routes/wallet';

export function createApp() {
  const app = express();

  app.use(cors());
  app.use(express.json());

  app.get('/health', (_req, res) => res.json({ ok: true }));

  app.use('/auth', authRoutes);
  app.use('/professionals', professionalsRoutes);
  app.use('/bookings', bookingsRoutes);
  app.use('/ratings', ratingsRoutes);
  app.use('/notifications', notificationsRoutes);
  app.use('/location-pings', locationPingsRoutes);
  app.use('/wallet', walletRoutes);

  app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    // eslint-disable-next-line no-console
    console.error(err);
    const status = typeof err?.statusCode === 'number' ? err.statusCode : 500;
    res.status(status).json({ error: status === 500 ? 'Internal server error' : err.message });
  });

  return app;
}
