import { Router } from 'express';
import { z } from 'zod';
import { db } from '../db/client';
import { notifications, pushTokens } from '../db/schema';
import { eq, desc } from 'drizzle-orm';
import { requireAuth, AuthedRequest } from '../middleware/auth';
import { sendPushToUser } from '../services/push';

const router = Router();

router.get('/', requireAuth, async (req: AuthedRequest, res) => {
  const rows = await db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, req.userId!))
    .orderBy(desc(notifications.timestamp));
  res.json({ notifications: rows });
});

router.post('/:id/read', requireAuth, async (req: AuthedRequest, res) => {
  const [updated] = await db
    .update(notifications)
    .set({ read: true })
    .where(eq(notifications.id, req.params.id))
    .returning();
  res.json({ notification: updated });
});

const registerTokenSchema = z.object({
  token: z.string().min(1),
  platform: z.enum(['ios', 'android', 'web']),
});

router.post('/device-token', requireAuth, async (req: AuthedRequest, res) => {
  const parsed = registerTokenSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

  const [token] = await db
    .insert(pushTokens)
    .values({ userId: req.userId!, token: parsed.data.token, platform: parsed.data.platform })
    .returning();
  res.status(201).json({ token });
});

export default router;

export async function notifyUser(userId: string, title: string, body: string, bookingId?: string) {
  const [row] = await db
    .insert(notifications)
    .values({ userId, title, body, bookingId })
    .returning();

  const tokens = await db.select().from(pushTokens).where(eq(pushTokens.userId, userId));
  void sendPushToUser(tokens, title, body);

  return row;
}
