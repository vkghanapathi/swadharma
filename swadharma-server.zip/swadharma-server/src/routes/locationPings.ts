import { Router } from 'express';
import { z } from 'zod';
import { db } from '../db/client';
import { locationPings, bookings } from '../db/schema';
import { eq, desc } from 'drizzle-orm';
import { requireAuth, AuthedRequest } from '../middleware/auth';

const router = Router();

const pingSchema = z.object({
  bookingId: z.string().uuid(),
  lat: z.string(),
  lng: z.string(),
});

router.post('/', requireAuth, async (req: AuthedRequest, res) => {
  const parsed = pingSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const d = parsed.data;

  const [booking] = await db.select().from(bookings).where(eq(bookings.id, d.bookingId));
  if (!booking) return res.status(404).json({ error: 'Booking not found' });
  if (booking.professionalId !== req.userId) {
    return res.status(403).json({ error: 'Not the professional for this booking' });
  }
  if (!['accepted', 'en_route', 'arrived', 'in_progress'].includes(booking.status)) {
    return res.status(409).json({ error: 'Booking is not in an active tracking window' });
  }

  const [ping] = await db
    .insert(locationPings)
    .values({ professionalId: req.userId!, bookingId: d.bookingId, lat: d.lat, lng: d.lng })
    .returning();

  res.status(201).json({ ping });
});

router.get('/:bookingId/latest', requireAuth, async (req: AuthedRequest, res) => {
  const [booking] = await db.select().from(bookings).where(eq(bookings.id, req.params.bookingId));
  if (!booking) return res.status(404).json({ error: 'Booking not found' });
  if (booking.requesterId !== req.userId) {
    return res.status(403).json({ error: 'Not the requester for this booking' });
  }

  const [latest] = await db
    .select()
    .from(locationPings)
    .where(eq(locationPings.bookingId, req.params.bookingId))
    .orderBy(desc(locationPings.timestamp))
    .limit(1);

  res.json({ ping: latest ?? null });
});

export default router;
