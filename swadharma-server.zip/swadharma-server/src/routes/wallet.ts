import { Router } from 'express';
import { db } from '../db/client';
import { walletTransactions } from '../db/schema';
import { eq, desc, sum } from 'drizzle-orm';
import { requireAuth, AuthedRequest } from '../middleware/auth';

const router = Router();

router.get('/', requireAuth, async (req: AuthedRequest, res) => {
  const transactions = await db
    .select()
    .from(walletTransactions)
    .where(eq(walletTransactions.userId, req.userId!))
    .orderBy(desc(walletTransactions.timestamp));

  const [{ total }] = await db
    .select({ total: sum(walletTransactions.amountPaise) })
    .from(walletTransactions)
    .where(eq(walletTransactions.userId, req.userId!));

  res.json({ balancePaise: Number(total ?? 0), transactions });
});

export default router;
