import { Router } from 'express';
import { z } from 'zod';
import { db } from '../db/client';
import { users } from '../db/schema';
import { eq } from 'drizzle-orm';
import { issueOtp, verifyOtp } from '../services/otp';
import { signToken, requireAuth, AuthedRequest } from '../middleware/auth';

const router = Router();

const phoneSchema = z.object({ phone: z.string().min(6) });

router.post('/otp/request', async (req, res) => {
  const parsed = phoneSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  await issueOtp(parsed.data.phone);
  res.json({ ok: true });
});

const verifySchema = z.object({ phone: z.string().min(6), code: z.string().length(6) });

router.post('/otp/verify', async (req, res) => {
  const parsed = verifySchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

  const { phone, code } = parsed.data;
  const valid = await verifyOtp(phone, code);
  if (!valid) return res.status(401).json({ error: 'Incorrect or expired code' });

  let [user] = await db.select().from(users).where(eq(users.phone, phone));
  if (!user) {
    [user] = await db.insert(users).values({ name: 'New User', phone, roles: [], languages: [] }).returning();
  }

  const token = signToken(user.id);
  res.json({ token, user });
});

// admin is deliberately not a valid value here — see users.isAdmin's
// comment in db/schema.ts. Same boundary as Parichara.
const rolesSchema = z.object({ roles: z.array(z.enum(['requester', 'professional'])).min(1) });

router.patch('/me/roles', requireAuth, async (req: AuthedRequest, res) => {
  const parsed = rolesSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

  const [updated] = await db
    .update(users)
    .set({ roles: parsed.data.roles })
    .where(eq(users.id, req.userId!))
    .returning();

  res.json({ user: updated });
});

router.get('/me', requireAuth, async (req: AuthedRequest, res) => {
  const [user] = await db.select().from(users).where(eq(users.id, req.userId!));
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ user });
});

export default router;
