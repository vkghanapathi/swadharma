import { Router } from 'express';
import { z } from 'zod';
import { db } from '../db/client';
import { professionalProfiles, users, ratings } from '../db/schema';
import { eq, and, ilike, avg, count, sql } from 'drizzle-orm';
import { requireAuth, AuthedRequest } from '../middleware/auth';

const router = Router();

const profileSchema = z.object({
  veda: z.string().optional(),
  shakha: z.string().optional(),
  sutra: z.string().optional(),
  specialties: z.array(z.string()).min(1),
  serviceAreaCity: z.string().optional(),
  bio: z.string().optional(),
});

// Create or update — a professional's own profile. No admin approval gate
// in this core scope (deferred — see the note at the top of db/schema.ts);
// setting the professional role plus a profile is enough to be searchable.
router.put('/me', requireAuth, async (req: AuthedRequest, res) => {
  const parsed = profileSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const d = parsed.data;

  const [existing] = await db
    .select()
    .from(professionalProfiles)
    .where(eq(professionalProfiles.userId, req.userId!));

  if (existing) {
    const [updated] = await db
      .update(professionalProfiles)
      .set({ ...d, updatedAt: new Date() })
      .where(eq(professionalProfiles.userId, req.userId!))
      .returning();
    return res.json({ profile: updated });
  }

  const [created] = await db
    .insert(professionalProfiles)
    .values({ userId: req.userId!, ...d })
    .returning();
  res.status(201).json({ profile: created });
});

router.get('/me', requireAuth, async (req: AuthedRequest, res) => {
  const [profile] = await db
    .select()
    .from(professionalProfiles)
    .where(eq(professionalProfiles.userId, req.userId!));
  if (!profile) return res.status(404).json({ error: 'No professional profile on file' });
  res.json({ profile });
});

// --- Search / filter ---
// The actual "search by rating/language/Veda/Śākhā/Sūtra/specialty"
// requirement. Rating is computed via a live AVG/COUNT join rather than a
// stored column — avoids a sync bug between the ratings table and a cached
// average, at the cost of a heavier query; fine at this scale, revisit with
// a materialized/cached average only if it becomes a real bottleneck.
router.get('/search', async (req, res) => {
  const { veda, shakha, sutra, specialty, language, minRating, city } = req.query as Record<
    string,
    string | undefined
  >;

  const conditions = [];
  if (veda) conditions.push(ilike(professionalProfiles.veda, `%${veda}%`));
  if (shakha) conditions.push(ilike(professionalProfiles.shakha, `%${shakha}%`));
  if (sutra) conditions.push(ilike(professionalProfiles.sutra, `%${sutra}%`));
  if (city) conditions.push(ilike(professionalProfiles.serviceAreaCity, `%${city}%`));
  if (specialty) conditions.push(sql`${specialty} = ANY(${professionalProfiles.specialties})`);
  if (language) conditions.push(sql`${language} = ANY(${users.languages})`);

  const rows = await db
    .select({
      userId: professionalProfiles.userId,
      name: users.name,
      languages: users.languages,
      veda: professionalProfiles.veda,
      shakha: professionalProfiles.shakha,
      sutra: professionalProfiles.sutra,
      specialties: professionalProfiles.specialties,
      serviceAreaCity: professionalProfiles.serviceAreaCity,
      bio: professionalProfiles.bio,
      avgRating: avg(ratings.stars),
      ratingCount: count(ratings.id),
    })
    .from(professionalProfiles)
    .innerJoin(users, eq(users.id, professionalProfiles.userId))
    .leftJoin(ratings, eq(ratings.ratedUserId, professionalProfiles.userId))
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .groupBy(
      professionalProfiles.userId,
      users.name,
      users.languages,
      professionalProfiles.veda,
      professionalProfiles.shakha,
      professionalProfiles.sutra,
      professionalProfiles.specialties,
      professionalProfiles.serviceAreaCity,
      professionalProfiles.bio
    );

  const filtered = minRating
    ? rows.filter((r) => Number(r.avgRating ?? 0) >= Number(minRating))
    : rows;

  res.json({ professionals: filtered });
});

export default router;
