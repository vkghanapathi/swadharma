import { Router } from 'express';
import { z } from 'zod';
import { db } from '../db/client';
import { ratings, bookings } from '../db/schema';
import { eq } from 'drizzle-orm';
import { requireAuth, AuthedRequest } from '../middleware/auth';

const router = Router();

const schema = z.object({
  bookingId: z.string().uuid(),
  stars: z.number().int().min(1).max(5),
  review: z.string().optional(),
});

router.post('/', requireAuth, async (req: AuthedRequest, res) => {
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const d = parsed.data;

  const [booking] = await db.select().from(bookings).where(eq(bookings.id, d.bookingId));
  if (!booking) return res.status(404).json({ error: 'Booking not found' });
  if (booking.requesterId !== req.userId) {
    return res.status(403).json({ error: 'Only the requester can rate this booking' });
  }
  if (booking.status !== 'completed') {
    return res.status(400).json({ error: 'Booking must be completed before rating' });
  }

  const [rating] = await db
    .insert(ratings)
    .values({
      bookingId: d.bookingId,
      ratedUserId: booking.professionalId,
      stars: d.stars,
      review: d.review,
    })
    .returning();

  res.status(201).json({ rating });
});

export default router;
