import { Router } from 'express';
import { z } from 'zod';
import { db } from '../db/client';
import { bookings, walletTransactions, professionalProfiles } from '../db/schema';
import { eq, or, and } from 'drizzle-orm';
import { requireAuth, AuthedRequest } from '../middleware/auth';
import { getPaymentProvider } from '../services/payment';
import { computeCancellationOutcome } from '../services/cancellationPolicy';
import { notifyUser } from './notifications';

const router = Router();

const createBookingSchema = z.object({
  professionalId: z.string().uuid(),
  specialty: z.string().min(1),
  description: z.string().min(1),
  eventLocation: z.object({
    lat: z.string(),
    lng: z.string(),
    address: z.string().optional(),
  }),
  eventDateTime: z.string().datetime().optional(),
  tokenAmountPaise: z.number().int().nonnegative().default(0),
});

router.post('/', requireAuth, async (req: AuthedRequest, res) => {
  const parsed = createBookingSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const d = parsed.data;

  const [profile] = await db
    .select()
    .from(professionalProfiles)
    .where(eq(professionalProfiles.userId, d.professionalId));
  if (!profile) {
    return res.status(404).json({ error: 'No professional profile found for that professional' });
  }

  const [created] = await db
    .insert(bookings)
    .values({
      requesterId: req.userId!,
      professionalId: d.professionalId,
      specialty: d.specialty,
      description: d.description,
      eventLocationLat: d.eventLocation.lat,
      eventLocationLng: d.eventLocation.lng,
      eventLocationAddress: d.eventLocation.address,
      eventDateTime: d.eventDateTime ? new Date(d.eventDateTime) : undefined,
      tokenAmountPaise: d.tokenAmountPaise,
      status: 'requested',
    })
    .returning();

  res.status(201).json({ booking: created });
});

router.get('/', requireAuth, async (req: AuthedRequest, res) => {
  const rows = await db
    .select()
    .from(bookings)
    .where(or(eq(bookings.requesterId, req.userId!), eq(bookings.professionalId, req.userId!)));
  res.json({ bookings: rows });
});

router.get('/:id', requireAuth, async (req, res) => {
  const [booking] = await db.select().from(bookings).where(eq(bookings.id, req.params.id));
  if (!booking) return res.status(404).json({ error: 'Booking not found' });
  res.json({ booking });
});

// --- Payment (create-order / confirm) ---
router.post('/:id/payment/create-order', requireAuth, async (req: AuthedRequest, res) => {
  const [booking] = await db.select().from(bookings).where(eq(bookings.id, req.params.id));
  if (!booking) return res.status(404).json({ error: 'Booking not found' });
  if (booking.requesterId !== req.userId) {
    return res.status(403).json({ error: 'Not the requester for this booking' });
  }
  if (booking.tokenAmountPaise <= 0) {
    return res.status(400).json({ error: 'Booking has no token amount to collect' });
  }
  if (booking.paymentStatus !== 'none') {
    return res.status(409).json({ error: `Payment already ${booking.paymentStatus} for this booking` });
  }

  const provider = getPaymentProvider();
  const { providerOrderId } = await provider.createOrder(booking.tokenAmountPaise, booking.id);

  const [updated] = await db
    .update(bookings)
    .set({ paymentProviderOrderId: providerOrderId, paymentStatus: 'created', updatedAt: new Date() })
    .where(eq(bookings.id, req.params.id))
    .returning();

  res.status(201).json({ booking: updated });
});

router.post('/:id/payment/confirm', requireAuth, async (req: AuthedRequest, res) => {
  const [booking] = await db.select().from(bookings).where(eq(bookings.id, req.params.id));
  if (!booking) return res.status(404).json({ error: 'Booking not found' });
  if (booking.requesterId !== req.userId) {
    return res.status(403).json({ error: 'Not the requester for this booking' });
  }
  if (booking.paymentStatus !== 'created' || !booking.paymentProviderOrderId) {
    return res.status(409).json({ error: 'No pending payment order to confirm' });
  }

  const provider = getPaymentProvider();
  await provider.capture(booking.paymentProviderOrderId, booking.tokenAmountPaise);

  const [updated] = await db
    .update(bookings)
    .set({ paymentStatus: 'captured', updatedAt: new Date() })
    .where(eq(bookings.id, req.params.id))
    .returning();

  await db.insert(walletTransactions).values({
    userId: booking.requesterId,
    amountPaise: -booking.tokenAmountPaise,
    reason: 'token_payment',
    bookingId: booking.id,
  });

  res.json({ booking: updated });
});

// --- Accept ---
router.post('/:id/accept', requireAuth, async (req: AuthedRequest, res) => {
  const [booking] = await db.select().from(bookings).where(eq(bookings.id, req.params.id));
  if (!booking) return res.status(404).json({ error: 'Booking not found' });
  if (booking.professionalId !== req.userId) {
    return res.status(403).json({ error: 'Not the professional this booking was made with' });
  }
  if (booking.status !== 'requested') {
    return res.status(409).json({ error: 'Booking is no longer available to accept' });
  }

  const [updated] = await db
    .update(bookings)
    .set({ status: 'accepted', updatedAt: new Date() })
    .where(and(eq(bookings.id, req.params.id), eq(bookings.status, 'requested')))
    .returning();

  if (!updated) {
    return res.status(409).json({ error: 'Booking is no longer available to accept' });
  }

  await notifyUser(
    updated.requesterId,
    'Booking accepted',
    `Your booking "${updated.description}" was accepted.`,
    updated.id
  );

  res.json({ booking: updated });
});

// --- Status progression ---
const statusSchema = z.object({
  status: z.enum(['en_route', 'arrived', 'in_progress', 'completed']),
});

router.patch('/:id/status', requireAuth, async (req: AuthedRequest, res) => {
  const parsed = statusSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

  const [booking] = await db.select().from(bookings).where(eq(bookings.id, req.params.id));
  if (!booking) return res.status(404).json({ error: 'Booking not found' });
  if (booking.professionalId !== req.userId) {
    return res.status(403).json({ error: 'Not the professional for this booking' });
  }

  const [updated] = await db
    .update(bookings)
    .set({ status: parsed.data.status, updatedAt: new Date() })
    .where(eq(bookings.id, req.params.id))
    .returning();

  res.json({ booking: updated });
});

// --- Cancellation ---
const cancelSchema = z.object({ reason: z.string().optional() });

router.post('/:id/cancel', requireAuth, async (req: AuthedRequest, res) => {
  const parsed = cancelSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

  const [booking] = await db.select().from(bookings).where(eq(bookings.id, req.params.id));
  if (!booking) return res.status(404).json({ error: 'Booking not found' });
  if (booking.requesterId !== req.userId && booking.professionalId !== req.userId) {
    return res.status(403).json({ error: 'Not a party to this booking' });
  }
  if (booking.status === 'completed' || booking.status === 'cancelled') {
    return res.status(409).json({ error: `Cannot cancel a booking that is already ${booking.status}` });
  }

  const cancelledBy: 'requester' | 'professional' =
    booking.requesterId === req.userId ? 'requester' : 'professional';
  const outcome = computeCancellationOutcome(booking, cancelledBy);

  const [updated] = await db
    .update(bookings)
    .set({ status: 'cancelled', updatedAt: new Date() })
    .where(eq(bookings.id, req.params.id))
    .returning();

  if (booking.paymentStatus === 'captured' && booking.paymentProviderOrderId) {
    if (outcome.refundPaise > 0) {
      const provider = getPaymentProvider();
      await provider.refund(booking.paymentProviderOrderId, outcome.refundPaise);
      await db.insert(walletTransactions).values({
        userId: booking.requesterId,
        amountPaise: outcome.refundPaise,
        reason: outcome.forfeitPaise > 0 ? 'cancellation_credit' : 'refund',
        bookingId: booking.id,
      });
    }
    if (outcome.forfeitPaise > 0 && outcome.compensateProfessional) {
      await db.insert(walletTransactions).values({
        userId: booking.professionalId,
        amountPaise: outcome.forfeitPaise,
        reason: 'payout',
        bookingId: booking.id,
      });
    }
    await db
      .update(bookings)
      .set({ paymentStatus: outcome.refundPaise > 0 ? 'refunded' : 'captured' })
      .where(eq(bookings.id, req.params.id));
  }

  res.json({ booking: updated, cancellationOutcome: outcome });
});

export default router;
