// Pluggable payment gateway. Selected via PAYMENT_PROVIDER env var:
//   - 'mock' (default): in-memory, always succeeds — this is what's been
//     tested end-to-end in this sandbox.
//   - 'razorpay': real Razorpay Orders/Payments API calls.
//
// IMPORTANT: 'razorpay' is written to Razorpay's real API contract
// (https://razorpay.com/docs/api/orders/, /payments/#capture-a-payment,
// /refunds/) but has NOT been exercised against the live service — this
// sandbox's network allowlist doesn't include api.razorpay.com. Test
// against a Razorpay test-mode account before relying on it.

export interface PaymentProvider {
  createOrder(amountPaise: number, requestId: string): Promise<{ providerOrderId: string }>;
  capture(providerOrderId: string, amountPaise: number): Promise<{ providerPaymentId: string }>;
  refund(providerOrderId: string, amountPaise: number): Promise<{ providerRefundId: string }>;
}

// In-memory only — orders don't survive a server restart. That's fine for
// a mock: it exists to prove the calling code's logic (routes, wallet
// ledger entries) is correct, not to be a durable payment record itself —
// the durable record is parichara_requests.paymentProviderOrderId /
// .paymentStatus plus the wallet_transactions ledger.
class MockPaymentProvider implements PaymentProvider {
  private orders = new Map<string, { amountPaise: number; captured: boolean }>();

  async createOrder(amountPaise: number, requestId: string) {
    const providerOrderId = `mock_order_${requestId}_${Date.now()}`;
    this.orders.set(providerOrderId, { amountPaise, captured: false });
    return { providerOrderId };
  }

  async capture(providerOrderId: string, amountPaise: number) {
    const order = this.orders.get(providerOrderId);
    if (!order) throw new Error(`Mock payment order ${providerOrderId} not found`);
    order.captured = true;
    return { providerPaymentId: `mock_payment_${providerOrderId}` };
  }

  async refund(providerOrderId: string, amountPaise: number) {
    const order = this.orders.get(providerOrderId);
    if (!order) throw new Error(`Mock payment order ${providerOrderId} not found`);
    return { providerRefundId: `mock_refund_${providerOrderId}_${amountPaise}` };
  }
}

// A single shared instance — a fresh MockPaymentProvider per call would
// forget every order immediately, making capture/refund always fail with
// "not found". Real gateways don't have this problem (the order lives on
// their server, not in this process), so this singleton is a mock-only
// concern — noted here rather than left as a silent surprise.
const mockProviderInstance = new MockPaymentProvider();

class RazorpayPaymentProvider implements PaymentProvider {
  private authHeader(): string {
    const keyId = process.env.RAZORPAY_KEY_ID;
    const keySecret = process.env.RAZORPAY_KEY_SECRET;
    if (!keyId || !keySecret) {
      throw new Error('RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET must be set to use the razorpay provider');
    }
    return `Basic ${Buffer.from(`${keyId}:${keySecret}`).toString('base64')}`;
  }

  async createOrder(amountPaise: number, requestId: string) {
    const res = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: this.authHeader() },
      body: JSON.stringify({
        amount: amountPaise, // Razorpay's `amount` is already in paise
        currency: 'INR',
        receipt: requestId,
      }),
    });
    if (!res.ok) throw new Error(`Razorpay createOrder failed: ${res.status} ${await res.text()}`);
    const data = (await res.json()) as { id: string };
    return { providerOrderId: data.id };
  }

  async capture(providerOrderId: string, amountPaise: number) {
    // Razorpay captures a *payment* (not an order) — providerOrderId here is
    // expected to actually be the payment id captured client-side via
    // Razorpay Checkout, passed through to this call. Wiring that handoff
    // (order -> client checkout -> payment id -> this capture call) is real
    // integration work belonging to the client, not sketched further here.
    const res = await fetch(`https://api.razorpay.com/v1/payments/${providerOrderId}/capture`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: this.authHeader() },
      body: JSON.stringify({ amount: amountPaise, currency: 'INR' }),
    });
    if (!res.ok) throw new Error(`Razorpay capture failed: ${res.status} ${await res.text()}`);
    const data = (await res.json()) as { id: string };
    return { providerPaymentId: data.id };
  }

  async refund(providerPaymentId: string, amountPaise: number) {
    const res = await fetch(`https://api.razorpay.com/v1/payments/${providerPaymentId}/refund`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: this.authHeader() },
      body: JSON.stringify({ amount: amountPaise }),
    });
    if (!res.ok) throw new Error(`Razorpay refund failed: ${res.status} ${await res.text()}`);
    const data = (await res.json()) as { id: string };
    return { providerRefundId: data.id };
  }
}

export function getPaymentProvider(): PaymentProvider {
  switch (process.env.PAYMENT_PROVIDER) {
    case 'razorpay':
      return new RazorpayPaymentProvider();
    default:
      return mockProviderInstance;
  }
}
