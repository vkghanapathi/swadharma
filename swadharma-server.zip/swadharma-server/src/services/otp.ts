import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { db } from '../db/client';
import { otpChallenges } from '../db/schema';
import { eq, and, isNull, gt, gte, count } from 'drizzle-orm';
import { getSmsProvider } from './smsProvider';
import { HttpError } from '../errors';

const OTP_TTL_MINUTES = 5;

// Rate limiting is DB-backed (counting rows in otp_challenges), not
// in-memory — an in-memory counter resets on every restart and doesn't work
// once this runs as more than one process, so it wouldn't actually be a
// rate limit under real load, just a speed bump in a single dev process.
const RATE_LIMIT_WINDOW_MINUTES = Number(process.env.OTP_RATE_LIMIT_WINDOW_MINUTES ?? 15);
const RATE_LIMIT_MAX_REQUESTS = Number(process.env.OTP_RATE_LIMIT_MAX ?? 5);

export function generateOtpCode(): string {
  return String(crypto.randomInt(100000, 999999));
}

export async function issueOtp(phone: string): Promise<void> {
  const windowStart = new Date(Date.now() - RATE_LIMIT_WINDOW_MINUTES * 60 * 1000);
  const [{ value: recentCount }] = await db
    .select({ value: count() })
    .from(otpChallenges)
    .where(and(eq(otpChallenges.phone, phone), gte(otpChallenges.createdAt, windowStart)));

  if (recentCount >= RATE_LIMIT_MAX_REQUESTS) {
    throw new HttpError(
      429,
      `Too many OTP requests for this number. Try again after ${RATE_LIMIT_WINDOW_MINUTES} minutes.`
    );
  }

  const code = generateOtpCode();
  const codeHash = await bcrypt.hash(code, 10);
  const expiresAt = new Date(Date.now() + OTP_TTL_MINUTES * 60 * 1000);

  await db.insert(otpChallenges).values({ phone, codeHash, expiresAt });

  const message = `Your Swadharma verification code is ${code}. It expires in ${OTP_TTL_MINUTES} minutes.`;
  await getSmsProvider().send(phone, message);
}

export async function verifyOtp(phone: string, code: string): Promise<boolean> {
  const candidates = await db
    .select()
    .from(otpChallenges)
    .where(
      and(
        eq(otpChallenges.phone, phone),
        isNull(otpChallenges.consumedAt),
        gt(otpChallenges.expiresAt, new Date())
      )
    );

  for (const challenge of candidates) {
    if (await bcrypt.compare(code, challenge.codeHash)) {
      await db
        .update(otpChallenges)
        .set({ consumedAt: new Date() })
        .where(eq(otpChallenges.id, challenge.id));
      return true;
    }
  }
  return false;
}
