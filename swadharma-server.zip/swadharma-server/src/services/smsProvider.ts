// Pluggable SMS delivery. Selected via SMS_PROVIDER env var:
//   - 'console' (default): logs the message, for local dev — never real SMS.
//   - 'msg91': real MSG91 API call (common for Indian phone verification).
//   - 'twilio': real Twilio Verify-style API call.
//
// IMPORTANT: 'msg91' and 'twilio' are written to their real API contracts
// but have NOT been exercised against the live services — this sandbox's
// network allowlist doesn't include their domains, so only 'console' has
// actually been run. Test the chosen real provider against a sandbox/test
// account before relying on it in production.

export interface SmsProvider {
  send(phone: string, message: string): Promise<void>;
}

class ConsoleSmsProvider implements SmsProvider {
  async send(phone: string, message: string): Promise<void> {
    // eslint-disable-next-line no-console
    console.log(`[dev-only sms] to ${phone}: ${message}`);
  }
}

// Real MSG91 API shape (https://api.msg91.com/api/v5/otp) — untested live,
// see file header.
class Msg91SmsProvider implements SmsProvider {
  async send(phone: string, message: string): Promise<void> {
    const apiKey = process.env.MSG91_AUTH_KEY;
    const templateId = process.env.MSG91_TEMPLATE_ID;
    if (!apiKey || !templateId) {
      throw new Error('MSG91_AUTH_KEY and MSG91_TEMPLATE_ID must be set to use the msg91 SMS provider');
    }

    const res = await fetch('https://api.msg91.com/api/v5/otp', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', authkey: apiKey },
      body: JSON.stringify({
        template_id: templateId,
        mobile: phone.replace(/^\+/, ''),
        otp: message.match(/\d{6}/)?.[0],
      }),
    });
    if (!res.ok) {
      throw new Error(`MSG91 SMS send failed: ${res.status} ${await res.text()}`);
    }
  }
}

// Real Twilio Verify API shape
// (https://www.twilio.com/docs/verify/api) — untested live, see file header.
class TwilioSmsProvider implements SmsProvider {
  async send(phone: string, message: string): Promise<void> {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const fromNumber = process.env.TWILIO_FROM_NUMBER;
    if (!accountSid || !authToken || !fromNumber) {
      throw new Error(
        'TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN and TWILIO_FROM_NUMBER must be set to use the twilio SMS provider'
      );
    }

    const basicAuth = Buffer.from(`${accountSid}:${authToken}`).toString('base64');
    const body = new URLSearchParams({ To: phone, From: fromNumber, Body: message });

    const res = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`, {
      method: 'POST',
      headers: {
        Authorization: `Basic ${basicAuth}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body,
    });
    if (!res.ok) {
      throw new Error(`Twilio SMS send failed: ${res.status} ${await res.text()}`);
    }
  }
}

export function getSmsProvider(): SmsProvider {
  switch (process.env.SMS_PROVIDER) {
    case 'msg91':
      return new Msg91SmsProvider();
    case 'twilio':
      return new TwilioSmsProvider();
    default:
      return new ConsoleSmsProvider();
  }
}
