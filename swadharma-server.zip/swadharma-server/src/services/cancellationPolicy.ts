import { bookings } from '../db/schema';

type BookingRow = typeof bookings.$inferSelect;

export type CancelledByRole = 'requester' | 'professional';

export interface CancellationOutcome {
  refundPaise: number;
  forfeitPaise: number;
  compensateProfessional: boolean;
  notes: string;
}

// Same tiering as Parichara's cancellationPolicy.ts — see that file's
// comments for the reasoning. Reproduced here rather than imported across
// repos since these are two separate deployable services; if a third
// project needs the same policy, that's the point to extract a shared
// package, not before.
export function computeCancellationOutcome(
  booking: BookingRow,
  cancelledBy: CancelledByRole
): CancellationOutcome {
  const capturedPaise = booking.paymentStatus === 'captured' ? booking.tokenAmountPaise : 0;

  if (cancelledBy === 'professional') {
    return {
      refundPaise: capturedPaise,
      forfeitPaise: 0,
      compensateProfessional: false,
      notes: 'Professional cancelled — full refund to requester.',
    };
  }

  switch (booking.status) {
    case 'requested':
      return {
        refundPaise: capturedPaise,
        forfeitPaise: 0,
        compensateProfessional: false,
        notes: 'Cancelled before the professional accepted — full refund.',
      };
    case 'accepted':
    case 'en_route':
    case 'arrived': {
      const half = Math.floor(capturedPaise / 2);
      return {
        refundPaise: half,
        forfeitPaise: capturedPaise - half,
        compensateProfessional: true,
        notes: 'Cancelled after acceptance but before the booking started — 50/50 split.',
      };
    }
    case 'in_progress':
      return {
        refundPaise: 0,
        forfeitPaise: capturedPaise,
        compensateProfessional: true,
        notes: 'Cancelled after the booking had already started — full forfeiture to the professional.',
      };
    default:
      return {
        refundPaise: 0,
        forfeitPaise: 0,
        compensateProfessional: false,
        notes: 'No applicable cancellation policy for this status.',
      };
  }
}
