// Pluggable push delivery. Selected via PUSH_PROVIDER env var:
//   - 'none' (default): logs only — no real push, for local dev.
//   - 'fcm': real Firebase Cloud Messaging legacy HTTP API call.
//
// IMPORTANT: 'fcm' is written to FCM's real (legacy) HTTP API shape but has
// NOT been exercised against the live service — this sandbox's network
// allowlist doesn't include fcm.googleapis.com. The legacy API (server-key
// auth) was used here instead of the newer HTTP v1 API specifically because
// v1 requires minting a short-lived OAuth2 access token from a service
// account, which is meaningfully more setup than fits a first pass — v1 is
// the one to migrate to for a real production rollout (Google has deprecated
// the legacy API), but this gets push working end-to-end sooner. Flagged
// here rather than silently shipping the deprecated path as if it were the
// long-term answer.

export interface PushProvider {
  send(token: string, title: string, body: string): Promise<void>;
}

class NullPushProvider implements PushProvider {
  async send(token: string, title: string, body: string): Promise<void> {
    // eslint-disable-next-line no-console
    console.log(`[dev-only push] to ${token.slice(0, 12)}...: ${title} — ${body}`);
  }
}

class FcmPushProvider implements PushProvider {
  async send(token: string, title: string, body: string): Promise<void> {
    const serverKey = process.env.FCM_SERVER_KEY;
    if (!serverKey) {
      throw new Error('FCM_SERVER_KEY must be set to use the fcm push provider');
    }

    const res = await fetch('https://fcm.googleapis.com/fcm/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `key=${serverKey}`,
      },
      body: JSON.stringify({
        to: token,
        notification: { title, body },
      }),
    });
    if (!res.ok) {
      throw new Error(`FCM push send failed: ${res.status} ${await res.text()}`);
    }
  }
}

export function getPushProvider(): PushProvider {
  switch (process.env.PUSH_PROVIDER) {
    case 'fcm':
      return new FcmPushProvider();
    default:
      return new NullPushProvider();
  }
}

// Sends to every token on file for a user. Best-effort: a push failure for
// one token (or all of them) must never bubble up and fail whatever action
// triggered the notification — the notifications table row is the durable
// record; push is purely a faster-delivery nicety on top of it.
export async function sendPushToUser(
  tokens: { token: string }[],
  title: string,
  body: string
): Promise<void> {
  const provider = getPushProvider();
  await Promise.all(
    tokens.map((t) =>
      provider.send(t.token, title, body).catch((err) => {
        // eslint-disable-next-line no-console
        console.error(`Push send failed for token ${t.token.slice(0, 12)}...:`, err);
      })
    )
  );
}
