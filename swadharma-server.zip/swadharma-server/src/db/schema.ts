import {
  pgTable,
  pgEnum,
  text,
  timestamp,
  boolean,
  integer,
  uuid,
} from 'drizzle-orm/pg-core';

// Scope note: this is the CORE booking build only — search/booking/
// live-location/payment/rating/cancellation. Explicitly deferred (per
// decision): 3-tier credentialing (SVAMI Certified / Credential Verified /
// Community Verified), hub-and-spoke multi-tenancy with RLS, pañcāṅga-aware
// muhūrta scheduling, the fixed donation-tier pricing model. Professionals
// here just have a self-declared profile — no formal empanelment gate yet,
// unlike Parichara's KYC+police-certificate flow. Add credentialing later
// without needing to redesign this core.

export const roleEnum = pgEnum('role', ['requester', 'professional']);

export const bookingStatusEnum = pgEnum('booking_status', [
  'requested',
  'accepted',
  'en_route',
  'arrived',
  'in_progress',
  'completed',
  'cancelled',
]);

export const paymentStatusEnum = pgEnum('payment_status', [
  'none',
  'created',
  'captured',
  'refunded',
  'failed',
]);

export const walletReasonEnum = pgEnum('wallet_reason', [
  'token_payment',
  'refund',
  'cancellation_credit',
  'payout',
  'settlement_adjustment',
]);

// --- Users ---
export const users = pgTable('users', {
  id: uuid('id').defaultRandom().primaryKey(),
  name: text('name').notNull(),
  phone: text('phone').notNull().unique(),
  // Separate from `roles` for the same reason as Parichara's users.isAdmin
  // — never reachable through the self-service role-selection endpoint.
  isAdmin: boolean('is_admin').notNull().default(false),
  // No .default([]) on array columns — drizzle-kit 0.20.18 generates
  // invalid SQL for that (see parichara-server's schema.ts comment and
  // README for how this was actually caught). Every insert supplies these
  // explicitly instead.
  roles: roleEnum('roles').array().notNull(),
  languages: text('languages').array().notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
});

// --- Professional profiles ---
// Self-declared for this core build — no admin approval gate yet. The
// search/filter fields (veda, shakha, sutra, specialty, language, rating)
// live here since they're exactly what the "search by rating/language/
// Veda/Śākhā/Sūtra/specialty" requirement needs to query against.
export const professionalProfiles = pgTable('professional_profiles', {
  userId: uuid('user_id')
    .primaryKey()
    .references(() => users.id, { onDelete: 'cascade' }),
  veda: text('veda'),
  shakha: text('shakha'),
  sutra: text('sutra'),
  specialties: text('specialties').array().notNull(),
  serviceAreaCity: text('service_area_city'),
  bio: text('bio'),
  updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
});

// --- Bookings ---
// Direct booking of a specific professional (found via search), not a
// broadcast/RFQ model — that's Contract Works' shape, not this one.
export const bookings = pgTable('bookings', {
  id: uuid('id').defaultRandom().primaryKey(),
  requesterId: uuid('requester_id')
    .notNull()
    .references(() => users.id),
  professionalId: uuid('professional_id')
    .notNull()
    .references(() => users.id),

  specialty: text('specialty').notNull(),
  description: text('description').notNull(),

  eventLocationLat: text('event_location_lat').notNull(),
  eventLocationLng: text('event_location_lng').notNull(),
  eventLocationAddress: text('event_location_address'),
  eventDateTime: timestamp('event_date_time', { withTimezone: true }),

  status: bookingStatusEnum('status').notNull().default('requested'),

  tokenAmountPaise: integer('token_amount_paise').notNull().default(0),
  paymentProvider: text('payment_provider').notNull().default('mock'),
  paymentProviderOrderId: text('payment_provider_order_id'),
  paymentStatus: paymentStatusEnum('payment_status').notNull().default('none'),

  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
});

// --- Ratings ---
export const ratings = pgTable('ratings', {
  id: uuid('id').defaultRandom().primaryKey(),
  bookingId: uuid('booking_id')
    .notNull()
    .references(() => bookings.id, { onDelete: 'cascade' }),
  ratedUserId: uuid('rated_user_id')
    .notNull()
    .references(() => users.id),
  stars: integer('stars').notNull(),
  review: text('review'),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
});

// --- Location pings (live tracking, Uber-like en-route view) ---
// Same retention concern as Parichara's — see scripts/cleanup-location-pings.ts.
export const locationPings = pgTable('location_pings', {
  id: uuid('id').defaultRandom().primaryKey(),
  professionalId: uuid('professional_id')
    .notNull()
    .references(() => users.id),
  bookingId: uuid('booking_id')
    .notNull()
    .references(() => bookings.id, { onDelete: 'cascade' }),
  lat: text('lat').notNull(),
  lng: text('lng').notNull(),
  timestamp: timestamp('timestamp', { withTimezone: true }).defaultNow().notNull(),
});

// --- Wallet transactions ---
export const walletTransactions = pgTable('wallet_transactions', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id')
    .notNull()
    .references(() => users.id),
  amountPaise: integer('amount_paise').notNull(),
  reason: walletReasonEnum('reason').notNull(),
  bookingId: uuid('booking_id').references(() => bookings.id),
  timestamp: timestamp('timestamp', { withTimezone: true }).defaultNow().notNull(),
});

// --- Notifications ---
export const notifications = pgTable('notifications', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id')
    .notNull()
    .references(() => users.id),
  title: text('title').notNull(),
  body: text('body').notNull(),
  bookingId: uuid('booking_id').references(() => bookings.id),
  timestamp: timestamp('timestamp', { withTimezone: true }).defaultNow().notNull(),
  read: boolean('read').notNull().default(false),
});

// --- OTP challenges ---
export const otpChallenges = pgTable('otp_challenges', {
  id: uuid('id').defaultRandom().primaryKey(),
  phone: text('phone').notNull(),
  codeHash: text('code_hash').notNull(),
  expiresAt: timestamp('expires_at', { withTimezone: true }).notNull(),
  consumedAt: timestamp('consumed_at', { withTimezone: true }),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
});

// --- Push tokens ---
export const pushPlatformEnum = pgEnum('push_platform', ['ios', 'android', 'web']);

export const pushTokens = pgTable('push_tokens', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id')
    .notNull()
    .references(() => users.id, { onDelete: 'cascade' }),
  token: text('token').notNull(),
  platform: pushPlatformEnum('platform').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
});
