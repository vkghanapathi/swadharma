import { Response, NextFunction } from 'express';
import { db } from '../db/client';
import { users } from '../db/schema';
import { eq } from 'drizzle-orm';
import { AuthedRequest } from './auth';

// isAdmin lives on the users row itself, not in the roles array — see the
// comment on users.isAdmin in db/schema.ts for why. This middleware is what
// actually protects admin-only routes (document review, empanelment
// approval); nothing about the JWT itself signals admin, so this always
// re-checks the DB rather than trusting a claim baked into the token.
export async function requireAdmin(req: AuthedRequest, res: Response, next: NextFunction) {
  if (!req.userId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }

  const [user] = await db.select().from(users).where(eq(users.id, req.userId));
  if (!user?.isAdmin) {
    return res.status(403).json({ error: 'Admin access required' });
  }

  next();
}
