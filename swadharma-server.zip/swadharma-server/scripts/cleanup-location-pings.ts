import 'dotenv/config';
import { db, pool } from '../src/db/client';
import { locationPings } from '../src/db/schema';
import { lt } from 'drizzle-orm';

async function main() {
  const retentionHours = Number(process.env.LOCATION_PING_RETENTION_HOURS ?? 24);
  const cutoff = new Date(Date.now() - retentionHours * 60 * 60 * 1000);

  const deleted = await db.delete(locationPings).where(lt(locationPings.timestamp, cutoff)).returning();

  console.log(`Deleted ${deleted.length} location ping(s) older than ${retentionHours}h (before ${cutoff.toISOString()}).`);
  await pool.end();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
