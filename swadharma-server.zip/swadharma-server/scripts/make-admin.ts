import 'dotenv/config';
import { db, pool } from '../src/db/client';
import { users } from '../src/db/schema';
import { eq } from 'drizzle-orm';

// Run with: npm run make-admin -- "+919000000000"
//
// This is deliberately the ONLY way to grant admin (short of a direct DB
// edit) — there is no API endpoint that does it, because an API endpoint
// reachable by an authenticated user is exactly what would let someone
// grant themselves admin. Whoever runs this script needs shell/DB access
// to the deployment already, which is the actual trust boundary.
async function main() {
  const phone = process.argv[2];
  if (!phone) {
    console.error('Usage: npm run make-admin -- "<phone>"');
    process.exit(1);
  }

  const [user] = await db.select().from(users).where(eq(users.phone, phone));
  if (!user) {
    console.error(`No user found with phone ${phone}. They must sign in at least once first.`);
    process.exit(1);
  }

  const [updated] = await db
    .update(users)
    .set({ isAdmin: true })
    .where(eq(users.phone, phone))
    .returning();

  console.log(`Granted admin to ${updated.name} (${updated.phone}, id ${updated.id}).`);
  await pool.end();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
